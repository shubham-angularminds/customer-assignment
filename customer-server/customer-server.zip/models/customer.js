const mongoose = require("mongoose");

const customerSchema = new mongoose.Schema({
  firstName: {
    type: String,
    trim: true,
    required: true,
  },
  lastName: {
    type: String,
    trim: true,
    required: true,
  },
  occupation: {
    type: String,
    trim: true,
    required: true,
  },
  dob: {
    type: String,
  },
  status: {
    type: String,
    trim: true,
    required: true,
  },
  bio: {
    type: String,
  },
  photo: {
    name: "String",
    data: Buffer,
    contentType: String,
  },
});

module.exports = mongoose.model("Customer", customerSchema);
